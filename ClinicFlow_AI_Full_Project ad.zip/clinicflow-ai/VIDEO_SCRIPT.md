# Video script (about 3 minutes)

Record your screen and speak in your own words. Use this as an outline, not a script to read out.

**0:00 Introduction.** "Hi, I'm Akash. I built ClinicFlow AI, an automation that helps clinics reduce missed appointments." Mention your ECE background and why automation interests you.

**0:20 The problem.** Missed appointments waste doctor time and delay care. Reception staff phone every patient by hand.

**0:40 AI tools.** "I used Claude to design and write the code, and Claude also powers the reminder writing inside the app. I chose it because it follows strict JSON instructions reliably and writes in several Indian languages."

**1:10 Prompt engineering.** Open `PROMPTS.md`. Explain the system prompt: role, JSON output, hard rules, length limit. Show the iteration table and the privacy bug you found and fixed.

**1:50 Challenges.** Invalid JSON from the model (fixed with strict parsing and a template fallback). An internal staff note leaking into an SMS (fixed by never sending it). Reviewers having no API key (fixed with demo mode).

**2:15 Demo.** Open the live web app. Show the call-first list, tap a patient, press "Write with AI", copy the SMS, mark the patient as confirmed and watch the numbers change. Then run `python app.py` in `python-workflow` and open `daily_report.md`.

**2:50 Outcome.** Staff phone only the high-risk patients and everyone else gets an automatic reminder. Next step: connect an SMS or WhatsApp service and a patient database.
